﻿namespace CSharp_Listener
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] url = { "http://localhost:5324/" };
            ListenerDemo.Listener1(url);
        }
    }
}
